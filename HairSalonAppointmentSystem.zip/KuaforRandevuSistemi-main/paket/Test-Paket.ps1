# Windows/.NET Framework: test only the contents of the distributed ZIP.
# Never start Program.Main or write to the user's application database.
[CmdletBinding()]
param([string]$ZipPath = (Join-Path $PSScriptRoot '../dagitim/KuaforRandevuSistemi-Windows.zip'))
$ErrorActionPreference = 'Stop'
$work = Join-Path ([IO.Path]::GetTempPath()) ('kuafor-test-' + [guid]::NewGuid())
try {
    Expand-Archive -LiteralPath $ZipPath -DestinationPath $work
    $expected = @('KuaforRandevuSistemi.exe', 'KuaforRandevuSistemi.exe.config', 'KULLANIM.txt',
        'System.Data.SQLite.dll', 'x86/SQLite.Interop.dll', 'x64/SQLite.Interop.dll')
    $actual = Get-ChildItem $work -File -Recurse -Force | ForEach-Object {
        $_.FullName.Substring($work.Length + 1).Replace('\', '/')
    }
    if (Compare-Object $expected $actual) { throw 'Unexpected or missing files in ZIP.' }

    # csc.exe is supplied with .NET Framework; no SDK or NuGet is needed here.
    $source = @'
using System;
using System.Data.SQLite;
using System.Reflection;
using System.Windows.Forms;
class Smoke {
    [STAThread] static void Main() {
        using (var db = new SQLiteConnection("Data Source=:memory:")) {
            db.Open();
            using (var cmd = new SQLiteCommand("SELECT sqlite_version()", db))
                Console.WriteLine("SQLite {0} ({1}-bit)", cmd.ExecuteScalar(), IntPtr.Size * 8);
        }
        var app = Assembly.LoadFrom("KuaforRandevuSistemi.exe");
        foreach (var type in app.GetTypes())
            if (typeof(Form).IsAssignableFrom(type))
                using (var form = (Form)Activator.CreateInstance(type)) {
                    Console.WriteLine(form.Text);
                    if (type.Name == "GirisFormu") {
                        form.Show();
                        ((ListBox)form.Controls["listBox1"]).SelectedItem = "Yasin";
                        ((TextBox)form.Controls["txtsifre"]).Text = "Yasin123";
                        form.AcceptButton.PerformClick();
                        var menu = Application.OpenForms["AnaMenuFormu"];
                        if (form.Visible || menu == null) throw new Exception("Demo login failed.");
                        menu.Dispose();
                    }
                }
    }
}
'@
    Push-Location $work
    try {
        Set-Content Smoke.cs $source -Encoding UTF8
        $platforms = @('x86')
        if ([Environment]::Is64BitOperatingSystem) { $platforms += 'x64' }
        foreach ($platform in $platforms) {
            & "$env:WINDIR/Microsoft.NET/Framework/v4.0.30319/csc.exe" /nologo "/platform:$platform" /out:Smoke.exe /r:System.Data.dll /r:System.Windows.Forms.dll /r:System.Data.SQLite.dll Smoke.cs
            if ($LASTEXITCODE -ne 0) { throw "Smoke test compile failed ($platform)." }
            $test = Start-Process (Join-Path $work 'Smoke.exe') -WorkingDirectory $work -NoNewWindow -PassThru
            try {
                if (-not $test.WaitForExit(30000)) {
                    $test.Kill()
                    $test.WaitForExit()
                    throw "Smoke test timed out ($platform)."
                }
                if ($test.ExitCode -ne 0) { throw "Smoke test failed ($platform)." }
            } finally { $test.Dispose() }
        }
    } finally { Pop-Location }
} finally {
    if (Test-Path $work) { Remove-Item -LiteralPath $work -Recurse -Force }
}
